// hello2.java
// Part of lab 1, short quote about CS
// Prints out quote 

class hello2{
   
    public static void main( String[] args ){
        System.out.print('"');
	System.out.println("I don't know why my program doesn't work!");
        System.out.print("I don't know why my program works!");
        System.out.print('"');
    }
}
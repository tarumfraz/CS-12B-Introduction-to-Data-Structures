// ***********************************************************************//
//  
// ** Option.java
// This file contains instances and the class Option for our cyoa game
//      
// ***********************************************************************//

class Option {

// =======================================================================// 
// Instances of class options    
// =======================================================================// 
  
  public String details;
  public String choiceTag;
  public Option nextOption;
  public String targetRoom;
 
}
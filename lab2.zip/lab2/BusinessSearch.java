// BusinessSearch.java
// This program reads an input file as an argument
// If the input file is not correctly entered, it displays a help message, and then temrinates
// If a file is submitted corrctly, this program builds an array of length N, mergesorts()'s the array,
//  and then waits for user input to enter a business name, and then uses binarySearch() to find the phone number
// if a space button is entered, the program terminates 
//
// In order to complete this program, I studied/used my notes from CS11, and studied
// the mergeSort() method and binarySearch() method in our textbooks
// Along with general simple questions from Google and Stack OverFlow (Example, "when to use a while loop")

import java.util.Scanner;
import java.io.*;

class BusinessSearch{

    public static String[] business;
    public static int arraySize,i;
    public static String fillArray;


    public static void main( String[] args ){

	Scanner sc = null;

	// if no arguments are entered, print out 
	// error message and correct way to invoke program
	if(args.length == 0){
	    errorMessage();
	}

	// Try and open the first argument on the command line
	try{
	    sc = new Scanner(new File(args[0]));
	}catch(FileNotFoundException e){
	    System.err.println(e.getMessage());
	    errorMessage();
	}

	// Read from the file that was on the command line
	while(sc.hasNext()){ //seemingly infinite loop, while there is another token
	    if(sc.hasNextInt()){ // if it happens to be an int
		arraySize = sc.nextInt(); // assign the int to the variable arraySizw
		business = new String[arraySize]; // allocate an array of length of array using variable
		
		sc.nextLine(); // Discard the next line 
		//Use a for loop to fill out our array
		for( i = 0; i < business.length; i++ ){
		    fillArray = sc.nextLine();
		    business[i] = fillArray;
		    
		}
		
	    }else{
		sc.next(); // If anything else, discard
	    }
	}
       
 
	mergeSort(business); // Call to function, in order to sucessfully sort our Array
        
	// Allocate space for a new scanner object
	// This scanner will be used to read user input
	Scanner scan = new Scanner(System.in); 

	int count = 0; //counter to keep track of # of iterations in while loop
	int notFound = 0;
	while(true){ // We don't know how many queries will be ran, so we use a while loop
	    String BusinessSearch = scan.nextLine(); // Assign the next line to a variable
	    count++;
	    if(BusinessSearch.equals( " ")){ // Terminate the program if a blank space is entered

		break;
	    }

	    System.out.println(bSearch( business, BusinessSearch )); // find value by conducting a binary search
	    if(bSearch( business, BusinessSearch ).equals("NOT FOUND")){ // keep track of "NOT FOUND" values
		notFound++;
	    }

	}

	System.out.println(count-1 + " total queries, " + notFound + " not found"); // Print out results of the session
    }
    
    // errorMessage()
    // prints out an error message with correct with to invoke program
    // terminates after instructions are given
    static void errorMessage(){
	System.err.println("You did not enter a business database file.");
	System.err.println("Please try again by running the program along with a business database file.");
	System.err.println("Once the program is correctly ran with a database file,");
	System.err.println("you can find the phone number of a business by typing");
	System.err.println("in the ENTIRE business name");
	System.exit(1);
    }
 
    // This method alphabetically sorts our array 
    public static void mergeSort( String[] B ){
	if(B.length >= 2){ // If the array is long enough
	    String[] LEFT = new String[B.length / 2]; // then split it in half, with 2 new arrays
	    String[] RIGHT = new String[B.length - B.length / 2];

	    for( int i = 0; i < LEFT.length; i++ ){ // Assign values to our new arrays
		LEFT[i] = B[i]; 
	    }
	    for( int i = 0; i < RIGHT.length; i++){
		RIGHT[i] = B[i + B.length / 2];
	    }

	    mergeSort(LEFT); // create two new arrays, untill no longer possible
	    mergeSort(RIGHT);
	    merge(B, LEFT, RIGHT); // Call to sort and merge function
	}
    }

    public static void merge( String[] M, String[] LEFT, String[] RIGHT ){
	int x = 0;
	int y = 0;
	// check the array, if appropiate, until in alphabetical order
	for( int i = 0; i < M.length; i++ ){
	    if( y >= RIGHT.length || (x < LEFT.length && LEFT[x].compareToIgnoreCase(RIGHT[y]) < 0 )){
		M[i] = LEFT[x];
		x++;
	    }else{
		M[i] = RIGHT[y];
		y++;
	    }
	}
    }

    // Call to binarySearch() method, to make it recursive
    public static String bSearch(String[] B, String searchBusiness){
	
	return binarySearch( B, searchBusiness, 0, B.length-1 );
    }

    public static String binarySearch( String[] B, String searchBusiness, int first, int last ){
	   
	String error = "NOT FOUND";

	if( first > last ) { // If the term is not in the array, return with "NOT FOUND" 
	    return error;
	}
	int middle = ( first + last ) / 2; 
	String str = B[middle]; // Splits our value in two, allowing us to use what we need
	String[] parts = str.split(",");
	String businessName = parts[0]; // the business name is before the comma
	String phoneNumber = parts[1]; // the phone number of the business is after the comma

	if( businessName.equals(searchBusiness)){ // If the search term is in the array
	    return phoneNumber; // return the phone number
	}else if( businessName.compareTo(searchBusiness) > 0 ){ // if not, keep trying by looking splitting array in half
	    return binarySearch( B, searchBusiness, first, middle - 1 );
	}else{
	    return binarySearch( B, searchBusiness, middle + 1, last);
	}
    }
}
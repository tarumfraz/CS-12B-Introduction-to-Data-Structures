// greetings.java
// Greet everyone listed in directory.txt
// Parses each line in directory.txt, and greets people by name,not the phone number
import static java.lang.System.*;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
class greetings {

    public static void main( String[] args ) throws IOException {
	BufferedReader in = new BufferedReader(
					       new FileReader("directory.txt"));
	
	while(true) {
	    try{
	    String name = in.readLine();
      	    if (name == null) break;
            String[] cut = name.split(",");
	    System.out.println("Hello, " + cut[0] + ".");
	    } catch(IOException e){
		System.err.println(e);
	    }
	}
	
	in.close();
    }
}